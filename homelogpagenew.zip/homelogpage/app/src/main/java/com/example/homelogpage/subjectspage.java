package com.example.homelogpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.content.Intent;
import android.view.View;

public class subjectspage extends AppCompatActivity {
    public ImageButton next;
    public Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjectspage);

        next = (ImageButton) findViewById(R.id.subtomath);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(subjectspage.this, mathscontent.class);
                startActivity(intent);
            }
        });

        button = (Button) findViewById(R.id.backtokidsec);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(subjectspage.this, kidsection.class);
                startActivity(intent);
            }
        });
    }
}