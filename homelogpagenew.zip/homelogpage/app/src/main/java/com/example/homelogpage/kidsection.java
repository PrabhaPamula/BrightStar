package com.example.homelogpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.content.Intent;
import android.view.View;

public class kidsection extends AppCompatActivity {
    public Button button;
    public ImageButton next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kid_sec);

        button = (Button) findViewById(R.id.kidtolog);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(kidsection.this, selectrole.class);
                startActivity(intent);
            }
        });

        next = (ImageButton) findViewById(R.id.kidtolearn);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(kidsection.this, subjectspage.class);
                startActivity(intent);
            }
        });
    }
}