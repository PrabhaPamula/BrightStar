package com.example.homelogpage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class subtractiontwo extends AppCompatActivity {
    public Button button1;
    public Button button2;
    public Button button3;
    AppCompatButton btn1, btn2, btn3, btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subtraction_two);

        button1 = (Button) findViewById(R.id.subtwotocontent);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(subtractiontwo.this, mathscontent.class);
                startActivity(intent);
            }
        });

        button2 = (Button) findViewById(R.id.subtwoto1);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(subtractiontwo.this, subtractionone.class);
                startActivity(intent);
            }
        });

        button3 = (Button) findViewById(R.id.subtwotosub3);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(subtractiontwo.this, subtractionthree.class);
                startActivity(intent);
            }
        });

        btn1 = findViewById(R.id.subtwocor);
        btn2 = findViewById(R.id.subtwowro1);
        btn3 = findViewById(R.id.subtwowro2);
        btn4 = findViewById(R.id.subtwowro3);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(subtractiontwo.this, "Correct Answer", Toast.LENGTH_SHORT).show();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(subtractiontwo.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(subtractiontwo.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(subtractiontwo.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
            }
        });

    }
}