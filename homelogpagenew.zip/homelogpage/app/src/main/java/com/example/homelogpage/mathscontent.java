package com.example.homelogpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;

public class mathscontent extends AppCompatActivity {
    public Button button;
    public Button button2;
    public Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mathscontent);

        button = (Button) findViewById(R.id.mathcontenttosub);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mathscontent.this, subjectspage.class);
                startActivity(intent);
            }
        });

        button2 = (Button) findViewById(R.id.btntoadd);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mathscontent.this, additionone.class);
                startActivity(intent);
            }
        });

        button3 = (Button) findViewById(R.id.contenttosub);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mathscontent.this, subtractionone.class);
                startActivity(intent);
            }
        });
    }
}