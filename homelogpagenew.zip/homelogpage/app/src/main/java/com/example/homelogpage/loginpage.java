package com.example.homelogpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;

public class loginpage extends AppCompatActivity {
    public Button button1;
    public Button button2;
    public  Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        button1 = (Button) findViewById(R.id.loginbackbtn);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginpage.this, MainActivity.class);
                startActivity(intent);
            }
        });

        button2 = (Button) findViewById(R.id.logtoselectrole);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginpage.this, selectrole.class);
                startActivity(intent);
            }
        });

        button3 = (Button) findViewById(R.id.logtosign);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginpage.this, signuppage.class);
                startActivity(intent);
            }
        });
    }
}