package com.example.homelogpage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class additiontwo extends AppCompatActivity {

    AppCompatButton btn1, btn2, btn3, btn4;
    public Button button;
    public Button button1;
    public Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addition_two);

        btn1 = findViewById(R.id.addtwocor);
        btn2 = findViewById(R.id.addtwowro3);
        btn3 = findViewById(R.id.addtwowro2);
        btn4 = findViewById(R.id.addtwowro1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(additiontwo.this, "Correct Answer", Toast.LENGTH_SHORT).show();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(additiontwo.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(additiontwo.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(additiontwo.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
            }
        });

        button = (Button) findViewById(R.id.backtoaddone);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(additiontwo.this, additionone.class);
                startActivity(intent);
            }
        });

        button1 = (Button) findViewById(R.id.addtocontent);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(additiontwo.this, mathscontent.class);
                startActivity(intent);
            }
        });

        button2 = (Button) findViewById(R.id.addtwotoaddthree);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(additiontwo.this, additionthree.class);
                startActivity(intent);
            }
        });

    }
}